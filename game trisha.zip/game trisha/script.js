const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 800;
canvas.height = 600;

let score = 0;
let playerSpeed = 5;

// Load gambar karakter dan item
const trishaImg = new Image();
trishaImg.src = "img/trisha.png";

const itemImg = new Image();
itemImg.src = "img/item.png";

// Posisi awal karakter
let player = { x: 100, y: 100, size: 64 };

// Posisi awal item
let item = { x: Math.random() * (canvas.width - 64), y: Math.random() * (canvas.height - 64), size: 32 };

// Event tombol
let keys = {};
document.addEventListener("keydown", (e) => { keys[e.key] = true; });
document.addEventListener("keyup", (e) => { keys[e.key] = false; });

// Update game
function update() {
    if (keys["ArrowUp"]) player.y -= playerSpeed;
    if (keys["ArrowDown"]) player.y += playerSpeed;
    if (keys["ArrowLeft"]) player.x -= playerSpeed;
    if (keys["ArrowRight"]) player.x += playerSpeed;

    // Batas layar
    if (player.x < 0) player.x = 0;
    if (player.y < 0) player.y = 0;
    if (player.x > canvas.width - player.size) player.x = canvas.width - player.size;
    if (player.y > canvas.height - player.size) player.y = canvas.height - player.size;

    // Cek tabrakan
    if (
        player.x < item.x + item.size &&
        player.x + player.size > item.x &&
        player.y < item.y + item.size &&
        player.y + player.size > item.y
    ) {
        score++;
        document.getElementById("score").innerText = score;
        // Pindahkan item ke posisi baru
        item.x = Math.random() * (canvas.width - item.size);
        item.y = Math.random() * (canvas.height - item.size);
    }
}

// Gambar game
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(trishaImg, player.x, player.y, player.size, player.size);
    ctx.drawImage(itemImg, item.x, item.y, item.size, item.size);
}

// Loop game
function gameLoop() {
    update();
    draw();
    requestAnimationFrame(gameLoop);
}

gameLoop();
