import pygame
import random
import sys

pygame.init()

# Ukuran layar
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Game Trisha Ngumpulin Batu")

# Warna
WHITE = (255, 255, 255)

# Load gambar
try:
    trisha_img = pygame.image.load("trisha.png")
    trisha_img = pygame.transform.scale(trisha_img, (80, 80))
except:
    print("❌ ERROR: File 'trisha.png' tidak ditemukan!")
    sys.exit()

try:
    batu_img = pygame.image.load("batu.png")
    batu_img = pygame.transform.scale(batu_img, (40, 40))
except:
    print("❌ ERROR: File 'batu.png' tidak ditemukan!")
    sys.exit()

# Posisi awal Trisha
trisha_x = WIDTH // 2
trisha_y = HEIGHT - 100
trisha_speed = 5

# Batu
batu_list = []
for _ in range(5):
    batu_x = random.randint(0, WIDTH - 40)
    batu_y = random.randint(0, HEIGHT - 200)
    batu_list.append(pygame.Rect(batu_x, batu_y, 40, 40))

# Skor
score = 0
font = pygame.font.Font(None, 36)

# Game loop
running = True
while running:
    screen.fill(WHITE)

    # Event
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Kontrol
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        trisha_x -= trisha_speed
    if keys[pygame.K_RIGHT]:
        trisha_x += trisha_speed
    if keys[pygame.K_UP]:
        trisha_y -= trisha_speed
    if keys[pygame.K_DOWN]:
        trisha_y += trisha_speed

    # Batas layar
    trisha_x = max(0, min(WIDTH - 80, trisha_x))
    trisha_y = max(0, min(HEIGHT - 80, trisha_y))

    # Gambar Trisha
    trisha_rect = pygame.Rect(trisha_x, trisha_y, 80, 80)
    screen.blit(trisha_img, trisha_rect)

    # Gambar dan cek tabrakan batu
    for batu in batu_list[:]:
        screen.blit(batu_img, batu)
        if trisha_rect.colliderect(batu):
            batu_list.remove(batu)
            score += 1

    # Skor
    skor_text = font.render(f"Skor: {score}", True, (0, 0, 0))
    screen.blit(skor_text, (10, 10))

    # Update layar
    pygame.display.flip()
    pygame.time.Clock().tick(60)

pygame.quit()
